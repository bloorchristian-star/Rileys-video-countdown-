EXTRA HIGH QUALITY FORFEIT VIDEO — LIVE COUNTDOWN

GitHub Pages setup:
1. Create a new GitHub repository.
2. Upload index.html to the root of the repository.
3. Go to Settings > Pages.
4. Under Build and deployment, choose 'Deploy from a branch'.
5. Select the main branch and '/ (root)', then Save.
6. GitHub will provide the live site address.

The countdown target is Tuesday 6 October 2026 at 8:00 PM UK time.
